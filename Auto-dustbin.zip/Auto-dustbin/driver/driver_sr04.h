#ifndef __DRIVER_SR04_H__
#define __DRIVER_SR04_H__

#include "main.h"

#define Tirg_ON HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,GPIO_PIN_SET)
#define Tirg_OFF HAL_GPIO_WritePin(GPIOB,GPIO_PIN_3,GPIO_PIN_SET)

void SR04_Tirgger(void);//touch signal

uint32_t GetDistance(void);//return void 

#endif
